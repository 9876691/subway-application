<?php
class Lru extends AppModel
{
    var $name = 'Lru';
}
?>