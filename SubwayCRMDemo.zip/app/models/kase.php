<?php
class Kase extends AppModel 
{
	var $name = 'Kase';
}
?>