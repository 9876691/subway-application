<?php
class File extends AppModel
{
    var $name = 'File';
}
?>