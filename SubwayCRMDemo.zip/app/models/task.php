<?php
class Task extends AppModel 
{
	var $name = 'Task';
}
?>