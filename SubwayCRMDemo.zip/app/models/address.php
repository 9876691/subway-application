<?php
class Address extends AppModel 
{
	var $name = 'Address';
}
?>