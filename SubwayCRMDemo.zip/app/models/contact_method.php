<?php
class ContactMethod extends AppModel 
{
   var $name = 'ContactMethod';
}
?>
