<?php
class DATABASE_CONFIG
{
	var $default = array(
		'driver' => 'mysql',
		'connect' => 'mysql_connect',
		'host' => 'localhost',
		'login' => 'subwaycrm.com',
		'password' => 'vja481xsub',
		'database' => 'subwaycrm_demo',
		'prefix' => '');
}
?>