<?php
class Tag extends AppModel 
{
	var $name = 'Tag';
}
?>