<?php
class Group extends AppModel 
{
	var $name = 'Group';
}
?>