<?php
class Attachment extends AppModel
{
    var $name = 'Attachment';
    var $useTable = 'files';
}
?>