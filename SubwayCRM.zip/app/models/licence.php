<?php
// I don't use this model, but it to stop licence controller failing due
// to no model erros
class Licence extends AppModel
{

  var $useTable = false;
}
?>
