<?php
class AssociationTag extends AppModel 
{
	var $name = 'AssociationTag';
}
?>