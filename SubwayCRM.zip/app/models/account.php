<?php
class Account extends AppModel 
{
	var $name = 'Account';
}
?>